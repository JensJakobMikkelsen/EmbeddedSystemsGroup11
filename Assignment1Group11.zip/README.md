# EmbeddedSystemsGroup11
Github repository for assignments
