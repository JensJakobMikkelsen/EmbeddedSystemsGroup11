// Exercise4.cpp : Defines the entry point for the console application.
//

#include "Top.h"

int sc_main(int argc, char* argv[])
{
	top instTop("instTop");

	sc_start(200, SC_MS);

	return 0;
}
